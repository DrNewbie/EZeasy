Hooks:PostHook(CustomSafehouseTweakData, "init", "EZ_CustomSafehouseTweakData_init", function(self, ...)
	self.combat.waves.EZeasy = 3
end)