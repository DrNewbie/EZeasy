Hooks:PostHook(TweakData, "_init_pd2", "EZ_TweakData__init_pd2", function(self, ...)
	self.hud_icons.risk_EZeasy = {
		texture = "guis/textures/pd2/hud_difficultymarkers_2",
		texture_rect = {
			30,
			32,
			30,
			30
		}
	}
end)